from django.contrib import admin
from . models import *
admin.site.register(notes)
admin.site.register(hw)
admin.site.register(td)

